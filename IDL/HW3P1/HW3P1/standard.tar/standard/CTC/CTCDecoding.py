import numpy as np


class GreedySearchDecoder(object):

    def __init__(self, symbol_set):
        """

        Initialize instance variables

        Argument(s)
        -----------

        symbol_set [list[str]]:
            all the symbols (the vocabulary without blank)

        """

        self.symbol_set = symbol_set

    def decode(self, y_probs):
        """

        Perform greedy search decoding

        Input
        -----

        y_probs [np.array, dim=(len(symbols) + 1, seq_length, batch_size)]
            batch size for part 1 will remain 1, but if you plan to use your
            implementation for part 2 you need to incorporate batch_size

        Returns
        -------

        decoded_path [str]:
            compressed symbol sequence i.e. without blanks or repeated symbols

        path_prob [float]:
            forward probability of the greedy path

        """

        decoded_path = []
        blank = 0
        path_prob = 1

        # TODO:
        # 1. Iterate over sequence length - len(y_probs[0])
        # 2. Iterate over symbol probabilities
        # 3. update path probability, by multiplying with the current max probability
        # 4. Select most probable symbol and append to decoded_path
        # 5. Compress sequence (Inside or outside the loop)
        for t in range(y_probs.shape[1]):
            max_index = np.argmax(y_probs[:, t, 0])
            max_prob = y_probs[max_index, t, 0]
            path_prob *= max_prob

            if max_index != blank:
                if len(decoded_path) == 0 or decoded_path[-1] != self.symbol_set[max_index - 1]:
                    decoded_path.append(self.symbol_set[max_index - 1])

        decoded_path = "".join(decoded_path)

        return decoded_path, path_prob
        # raise NotImplementedError


class BeamSearchDecoder(object):

    def __init__(self, symbol_set, beam_width):
        """
        Initialize instance variables.

        Parameters
        -----------
        symbol_set [list[str]]:
            All symbols (vocabulary excluding the blank symbol)

        beam_width [int]:
            Beam width to select the top k paths

        """

        self.symbol_set = symbol_set
        self.beam_width = beam_width

    def decode(self, y_probs):
        """
        Performs beam search decoding.

        Inputs
        -----
        y_probs [np.array, dim=(len(symbols) + 1, seq_length, batch_size)]
                In Part 1, the batch size is 1, but for Part 2, implement it to include batch size.

        Returns
        -------

        forward_path [str]:
            The symbol sequence with the highest path score (forward probability)

        merged_path_scores [dict]:
            All final merged paths and their scores

        """

        T = y_probs.shape[1]  # Number of time steps
        blank_index = 0  # Index of the blank symbol

        # Initialization:
        # Initialize BestPaths as a dictionary mapping an empty path to score 1.0
        BestPaths = {(): 1.0}

        for t in range(T):
            TempBestPaths = {}  # Dictionary to temporarily store top paths
            # Iterate over current top paths
            for path, score in BestPaths.items():
                # Iterate over all possible symbols (including blank)
                for s_index in range(len(self.symbol_set) + 1):
                    s_prob = y_probs[s_index, t, 0]  # Probability of the current symbol
                    new_score = score * s_prob  # Calculate new path score

                    if s_index == blank_index:
                        # If the symbol is blank
                        s = "-"
                    else:
                        # If the symbol is not blank
                        s = self.symbol_set[s_index - 1]

                    # Apply path extension rules
                    if len(path) == 0:
                        # If the current path is empty, add the new symbol
                        new_path = path + (s,)
                    else:
                        if path[-1] == "-":
                            if s == "-":
                                # blank + blank case
                                new_path = path
                            elif len(path) == 1:
                                # single blank + symbol case
                                new_path = (s,)
                            else:
                                # path ends with blank + symbol case
                                new_path = path[:-1] + (s,)
                        else:
                            if s == "-":
                                # symbol + blank case
                                new_path = path + (s,)
                            elif s == path[-1]:
                                # same symbol case
                                new_path = path
                            else:
                                # different symbol case
                                new_path = path + (s,)

                    # Update new path and score in TempBestPaths
                    if new_path in TempBestPaths:
                        TempBestPaths[new_path] += new_score
                    else:
                        TempBestPaths[new_path] = new_score

            # Select only the top beam_width paths
            sorted_paths = sorted(TempBestPaths.items(), key=lambda x: x[1], reverse=True)
            BestPaths = dict(sorted_paths[: self.beam_width])

        # At the end, remove blanks and merge paths
        MergedPathScores = {}
        for path, score in TempBestPaths.items():
            score = np.array([score])
            # Remove trailing blank
            if path[-1] == "-":
                path = path[:-1]
            # Remove blank symbols and convert to string
            path_str = "".join([c for c in path if c != "-"])
            # Sum scores of identical paths
            if path_str in MergedPathScores:
                MergedPathScores[path_str] += score
            else:
                MergedPathScores[path_str] = score
        # Sort by key values
        MergedPathScores = dict(sorted(MergedPathScores.items(), key=lambda x: x[1], reverse=True))

        # Select the path with the highest score
        BestPath = max(MergedPathScores.items(), key=lambda x: x[1])[0]

        return BestPath, MergedPathScores
