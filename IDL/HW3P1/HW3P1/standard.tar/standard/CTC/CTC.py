import numpy as np


class CTC(object):

    def __init__(self, BLANK=0):
        """
        Initialize instance variables

        Argument(s)
        -----------

        BLANK (int, optional): blank label index. Default 0.

        """

        # No need to modify
        self.BLANK = BLANK

    def extend_target_with_blank(self, target):
        """Extend target sequence with blank.

        Input
        -----
        target: (np.array, dim = (target_len,))
                target output
        ex: [B,IY,IY,F]

        Return
        ------
        extended_symbols: (np.array, dim = (2 * target_len + 1,))
                          extended target sequence with blanks
        ex: [-,B,-,IY,-,IY,-,F,-]

        skip_connect: (np.array, dim = (2 * target_len + 1,))
                      skip connections
        ex: [0,0,0,1,0,0,0,1,0]
        """

        # Initialize extended symbols with blanks
        extended_symbols = []
        skip_connect = []

        target_len = len(target)
        for i in range(target_len):
            # Append blank
            extended_symbols.append(self.BLANK)
            skip_connect.append(0)  # No skip connection at blank

            # Append actual symbol
            extended_symbols.append(target[i])
            if i > 0 and target[i] != target[i - 1]:
                # Allow skip connection if current and previous symbols are different
                skip_connect.append(1)
            else:
                skip_connect.append(0)

        # Append final blank
        extended_symbols.append(self.BLANK)
        skip_connect.append(0)

        N = len(extended_symbols)

        extended_symbols = np.array(extended_symbols).reshape((N,))
        skip_connect = np.array(skip_connect).reshape((N,))

        return extended_symbols, skip_connect

    def get_forward_probs(self, logits, extended_symbols, skip_connect):
        """Compute forward probabilities.

        Input
        -----
        logits: (np.array, dim = (input_len, len(Symbols)))
                predict (log) probabilities

                To get a certain symbol i's logit at a certain time stamp t:
                p(t,s(i)) = logits[t, extSymbols[i]]

        extSymbols: (np.array, dim = (2 * target_len + 1,))
                    extended label sequence with blanks

        skip_connect: (np.array, dim = (2 * target_len + 1,))
                      skip connections

        Return
        ------
        alpha: (np.array, dim = (input_len, 2 * target_len + 1))
               forward probabilities

        """

        S = len(extended_symbols)
        T = len(logits)
        alpha = np.zeros((T, S))

        # Initialization (t = 0)
        alpha[0, 0] = logits[0, extended_symbols[0]]
        if S > 1:
            alpha[0, 1] = logits[0, extended_symbols[1]]

        # Recursive computation over time
        for t in range(1, T):
            for s in range(S):
                # Get the symbol index
                sym_idx = extended_symbols[s]

                # Compute alpha[t, s]
                a = alpha[t - 1, s]

                b = alpha[t - 1, s - 1] if s - 1 >= 0 else 0

                c = alpha[t - 1, s - 2] if s - 2 >= 0 and skip_connect[s] == 1 else 0

                alpha[t, s] = (a + b + c) * logits[t, sym_idx]

        return alpha

    def get_backward_probs(self, logits, extended_symbols, skip_connect):
        """Compute backward probabilities.

        Input
        -----
        logits: (np.array, dim = (input_len, len(symbols)))
                predict (log) probabilities

                To get a certain symbol i's logit at a certain time stamp t:
                p(t,s(i)) = logits[t, extSymbols[i]]

        extSymbols: (np.array, dim = (2 * target_len + 1,))
                    extended label sequence with blanks

        skip_connect: (np.array, dim = (2 * target_len + 1,))
                    skip connections

        Return
        ------
        beta: (np.array, dim = (input_len, 2 * target_len + 1))
              backward probabilities

        """

        S = len(extended_symbols)
        T = len(logits)
        beta = np.zeros((T, S))

        # Initialization (t = T - 1)
        beta[T - 1, S - 1] = 1
        if S > 1:
            beta[T - 1, S - 2] = 1

        # Recursive computation backward in time
        for t in range(T - 2, -1, -1):
            for s in range(S):
                # Get the symbol index
                sym_idx = extended_symbols[s]

                # Compute beta[t, s]
                a = beta[t + 1, s] * logits[t + 1, sym_idx]

                b = beta[t + 1, s + 1] * logits[t + 1, extended_symbols[s + 1]] if s + 1 < S else 0

                c = (
                    beta[t + 1, s + 2] * logits[t + 1, extended_symbols[s + 2]]
                    if s + 2 < S and skip_connect[s + 2] == 1
                    else 0
                )

                beta[t, s] = a + b + c

        return beta

    def get_posterior_probs(self, alpha, beta):
        """Compute posterior probabilities.

        Input
        -----
        alpha: (np.array, dim = (input_len, 2 * target_len + 1))
               forward probability

        beta: (np.array, dim = (input_len, 2 * target_len + 1))
              backward probability

        Return
        ------
        gamma: (np.array, dim = (input_len, 2 * target_len + 1))
               posterior probability

        """

        T, S = alpha.shape
        gamma = np.zeros((T, S))

        # Compute total probability of the sequence
        seq_prob = alpha[-1, -1] + alpha[-1, -2] if S > 1 else alpha[-1, -1]

        # Compute gamma[t, s]
        for t in range(T):
            for s in range(S):
                gamma[t, s] = (alpha[t, s] * beta[t, s]) / seq_prob

        return gamma


class CTCLoss(object):

    def __init__(self, BLANK=0):
        """
        Initialize instance variables

        Argument(s)
        -----------
        BLANK (int, optional): blank label index. Default 0.

        """
        # No need to modify
        super(CTCLoss, self).__init__()

        self.BLANK = BLANK
        self.gammas = []
        self.ctc = CTC(BLANK=self.BLANK)
        # <---------------------------------------------

    def __call__(self, logits, target, input_lengths, target_lengths):

        # No need to modify
        return self.forward(logits, target, input_lengths, target_lengths)

    def forward(self, logits, target, input_lengths, target_lengths):
        """CTC loss forward

        Computes the CTC Loss by calculating forward, backward, and
        posterior probabilities, and then calculating the avg. loss between
        targets and predicted log probabilities

        Input
        -----
        logits [np.array, dim=(seq_length, batch_size, len(symbols)]:
            log probabilities (output sequence) from the RNN/GRU

        target [np.array, dim=(batch_size, padded_target_len)]:
            target sequences

        input_lengths [np.array, dim=(batch_size,)]:
            lengths of the inputs

        target_lengths [np.array, dim=(batch_size,)]:
            lengths of the target

        Returns
        -------
        loss [float]:
            avg. divergence between the posterior probability and the target

        """

        # No need to modify
        self.logits = logits
        self.target = target
        self.input_lengths = input_lengths
        self.target_lengths = target_lengths

        #####  IMP:
        #####  Output losses should be the mean loss over the batch

        # No need to modify
        B, _ = target.shape
        total_loss = np.zeros(B)
        self.extended_symbols = []
        self.gammas = []

        for batch_itr in range(B):
            # Truncate the target to target length
            target_seq = target[batch_itr, : self.target_lengths[batch_itr]]
            # Truncate the logits to input length
            logits_seq = logits[: self.input_lengths[batch_itr], batch_itr, :]

            # Extend target sequence with blank
            ext_symbols, skip_connect = self.ctc.extend_target_with_blank(target_seq)
            self.extended_symbols.append(ext_symbols)

            # Compute forward probabilities
            alpha = self.ctc.get_forward_probs(logits_seq, ext_symbols, skip_connect)

            # Compute backward probabilities
            beta = self.ctc.get_backward_probs(logits_seq, ext_symbols, skip_connect)

            # Compute posteriors using total probability function
            gamma = self.ctc.get_posterior_probs(alpha, beta)
            self.gammas.append(gamma)

            # Compute expected divergence for each batch
            T = logits_seq.shape[0]
            loss = 0
            for t in range(T):
                for s in range(len(ext_symbols)):
                    idx = ext_symbols[s]
                    if gamma[t, s] > 0 and logits_seq[t, idx] > 0:
                        loss -= gamma[t, s] * np.log(logits_seq[t, idx])

            total_loss[batch_itr] = loss

        total_loss = np.sum(total_loss) / B

        return total_loss

    def backward(self):
        """
        CTC loss backward

        Calculate the gradients w.r.t the parameters and return the derivative
        w.r.t the inputs, xt and ht, to the cell.

        Input
        -----
        logits [np.array, dim=(seq_length, batch_size, len(Symbols)]:
            log probabilities (output sequence) from the RNN/GRU

        target [np.array, dim=(batch_size, padded_target_len)]:
            target sequences

        input_lengths [np.array, dim=(batch_size,)]:
            lengths of the inputs

        target_lengths [np.array, dim=(batch_size,)]:
            lengths of the target

        Returns
        -------
        dY [np.array, dim=(seq_length, batch_size, len(symbols))]:
            derivative of divergence w.r.t the input symbols at each time

        """

        # No need to modify
        T_max, B, C = self.logits.shape
        dY = np.zeros_like(self.logits)

        for batch_itr in range(B):
            # Truncate the target to target length
            target_seq = self.target[batch_itr, : self.target_lengths[batch_itr]]
            # Truncate the logits to input length
            logits_seq = self.logits[: self.input_lengths[batch_itr], batch_itr, :]

            # Get extended symbols and gamma for this batch
            ext_symbols = self.extended_symbols[batch_itr]
            gamma = self.gammas[batch_itr]

            T = logits_seq.shape[0]

            for t in range(T):
                for c in range(C):
                    idxs = np.where(ext_symbols == c)[0]
                    dY_t_c = 0
                    for s in idxs:
                        dY_t_c -= gamma[t, s] / logits_seq[t, c]
                    dY[t, batch_itr, c] = dY_t_c

        return dY
