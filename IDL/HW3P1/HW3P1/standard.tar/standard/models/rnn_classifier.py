import numpy as np
import sys

sys.path.append("mytorch")
from rnn_cell import *
from nn.linear import *


class RNNPhonemeClassifier(object):
    """RNN Phoneme Classifier class."""

    def __init__(self, input_size, hidden_size, output_size, num_layers=2):
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        # Initialize RNN layers
        self.rnn = [
            RNNCell(input_size, hidden_size) if i == 0 else RNNCell(hidden_size, hidden_size) for i in range(num_layers)
        ]
        self.output_layer = Linear(hidden_size, output_size)

        # Store hidden states at each time step
        # [(seq_len+1) * (num_layers, batch_size, hidden_size)]
        self.hiddens = []

    def init_weights(self, rnn_weights, linear_weights):
        """Initialize weights.

        Parameters
        ----------
        rnn_weights:
                    [
                        [W_ih_l0, W_hh_l0, b_ih_l0, b_hh_l0],
                        [W_ih_l1, W_hh_l1, b_ih_l1, b_hh_l1],
                        ...
                    ]

        linear_weights:
                        [W, b]

        """
        for i, rnn_cell in enumerate(self.rnn):
            rnn_cell.init_weights(*rnn_weights[i])
        self.output_layer.W = linear_weights[0]
        self.output_layer.b = linear_weights[1].reshape(-1, 1)

    def __call__(self, x, h_0=None):
        return self.forward(x, h_0)

    def forward(self, x, h_0=None):
        """RNN forward, multiple layers, multiple time steps.

        Parameters
        ----------
        x: (batch_size, seq_len, input_size)
            Input

        h_0: (num_layers, batch_size, hidden_size)
            Initial hidden states. Defaults to zeros if not specified

        Returns
        -------
        logits: (batch_size, output_size)

        Output (y): logits

        """
        batch_size, seq_len = x.shape[0], x.shape[1]
        if h_0 is None:
            hidden = np.zeros((self.num_layers, batch_size, self.hidden_size), dtype=float)
        else:
            hidden = h_0

        # Save x and append the initial hidden state to the hiddens list
        self.x = x
        self.hiddens = []
        self.hiddens.append(hidden.copy())

        for t in range(seq_len):
            # For each layer
            for l in range(self.num_layers):
                if l == 0:
                    h_prev_l = x[:, t, :]  # Input at time t
                else:
                    h_prev_l = hidden[l - 1]  # Hidden state from previous layer at time t

                h_prev_t = hidden[l]  # Hidden state from previous time step at layer l

                # Compute the current hidden state
                h_t = self.rnn[l](h_prev_l, h_prev_t)
                hidden[l] = h_t  # Update hidden state for layer l

            # Append a copy of hidden states at this time step
            self.hiddens.append(hidden.copy())

        # Compute logits using the last hidden state of the last layer
        logits = self.output_layer(hidden[-1])

        return logits

    def backward(self, delta):
        """RNN Back Propagation Through Time (BPTT).

        Parameters
        ----------
        delta: (batch_size, output_size)
            Gradient w.r.t. the output logits.

        Returns
        -------
        dh_0: (num_layers, batch_size, hidden_size)
            Gradient w.r.t. the initial hidden states.

        """
        batch_size, seq_len = self.x.shape[0], self.x.shape[1]
        dh = np.zeros((self.num_layers, batch_size, self.hidden_size), dtype=float)

        # Backward pass through the output layer
        dh_output = self.output_layer.backward(delta)
        dh[-1] = dh_output  # Gradient w.r.t. the last hidden state of the last layer

        # Backpropagate through time
        for t in reversed(range(seq_len)):
            for l in reversed(range(self.num_layers)):
                if l == 0:
                    h_prev_l = self.x[:, t, :]  # Input at time t
                else:
                    h_prev_l = self.hiddens[t + 1][l - 1]  # Hidden state from previous layer at time t

                h_t = self.hiddens[t + 1][l]  # Hidden state at time t for layer l
                h_prev_t = self.hiddens[t][l]  # Hidden state at time t-1 for layer l

                delta = dh[l]

                # Backward pass through the RNN cell
                dx, dh_prev_t = self.rnn[l].backward(delta, h_t, h_prev_l, h_prev_t)

                dh[l] = dh_prev_t  # Update dh for layer l

                if l > 0:
                    dh[l - 1] += dx  # Accumulate gradient from higher layer
                else:
                    # Optionally, you can store dx if needed
                    pass

        # Normalize dh by batch_size since initial hidden states are treated as parameters
        dh_0 = dh / batch_size

        return dh_0
