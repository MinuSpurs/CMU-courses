import numpy as np
from mytorch.nn.activation import *


class GRUCell(object):
    """GRU Cell class."""

    def __init__(self, input_size, hidden_size):
        self.d = input_size
        self.h = hidden_size
        h = self.h
        d = self.d

        # Initialize weights
        self.Wrx = np.random.randn(h, d)
        self.Wzx = np.random.randn(h, d)
        self.Wnx = np.random.randn(h, d)

        self.Wrh = np.random.randn(h, h)
        self.Wzh = np.random.randn(h, h)
        self.Wnh = np.random.randn(h, h)

        self.brx = np.random.randn(h)
        self.bzx = np.random.randn(h)
        self.bnx = np.random.randn(h)

        self.brh = np.random.randn(h)
        self.bzh = np.random.randn(h)
        self.bnh = np.random.randn(h)

        # Initialize gradients
        self.dWrx = np.zeros((h, d))
        self.dWzx = np.zeros((h, d))
        self.dWnx = np.zeros((h, d))

        self.dWrh = np.zeros((h, h))
        self.dWzh = np.zeros((h, h))
        self.dWnh = np.zeros((h, h))

        self.dbrx = np.zeros(h)
        self.dbzx = np.zeros(h)
        self.dbnx = np.zeros(h)

        self.dbrh = np.zeros(h)
        self.dbzh = np.zeros(h)
        self.dbnh = np.zeros(h)

        # Activation functions
        self.r_act = Sigmoid()
        self.z_act = Sigmoid()
        self.h_act = Tanh()

        # Variables to store forward pass results
        self.x = None
        self.hidden = None
        self.r = None
        self.z = None
        self.n = None
        self.h_t = None
        self.r_t_pre = None
        self.z_t_pre = None
        self.n_t_pre = None

    def init_weights(self, Wrx, Wzx, Wnx, Wrh, Wzh, Wnh, brx, bzx, bnx, brh, bzh, bnh):
        self.Wrx = Wrx
        self.Wzx = Wzx
        self.Wnx = Wnx
        self.Wrh = Wrh
        self.Wzh = Wzh
        self.Wnh = Wnh
        self.brx = brx
        self.bzx = bzx
        self.bnx = bnx
        self.brh = brh
        self.bzh = bzh
        self.bnh = bnh

    def __call__(self, x, h_prev_t):
        return self.forward(x, h_prev_t)

    def forward(self, x, h_prev_t):
        """GRU cell forward."""
        self.x = x
        self.hidden = h_prev_t

        # Reset gate
        self.r_t_pre = self.Wrx @ self.x + self.brx + self.Wrh @ self.hidden + self.brh
        self.r = self.r_act.forward(self.r_t_pre)

        # Update gate
        self.z_t_pre = self.Wzx @ self.x + self.bzx + self.Wzh @ self.hidden + self.bzh
        self.z = self.z_act.forward(self.z_t_pre)

        # Candidate hidden state
        self.n_t_pre = self.Wnx @ self.x + self.bnx + self.r * (self.Wnh @ self.hidden + self.bnh)
        self.n = self.h_act.forward(self.n_t_pre)

        # Current hidden state
        h_t = (1 - self.z) * self.n + self.z * self.hidden
        self.h_t = h_t  # Store for backward pass

        # Assertions
        assert self.x.shape == (self.d,)
        assert self.hidden.shape == (self.h,)
        assert self.r.shape == (self.h,)
        assert self.z.shape == (self.h,)
        assert self.n.shape == (self.h,)
        assert h_t.shape == (self.h,)

        return h_t

    def backward(self, delta):
        """GRU cell backward."""
        dh_next = delta  # (hidden_dim,)

        # Gradients of h_t with respect to n, z, and h_prev
        dn = dh_next * (1 - self.z)  # (hidden_dim,)
        dz = dh_next * (-self.n + self.hidden)  # (hidden_dim,)
        dh_prev = dh_next * self.z  # Initialize dh_prev (hidden_dim,)

        # Backprop through tanh activation for n_t_pre
        dn_t_pre = self.h_act.backward(dn, state=self.n)  # (hidden_dim,)

        # Gradient wrt n_t_pre components
        # For Wnx, bnx, and x
        self.dWnx += np.outer(dn_t_pre, self.x)
        self.dbnx += dn_t_pre
        dx_n = self.Wnx.T @ dn_t_pre  # (input_dim,)

        # For Wnh, bnh, and h_prev
        dWnh_part = np.outer(dn_t_pre, self.hidden)
        self.dWnh += dWnh_part * self.r.reshape(-1, 1)
        self.dbnh += dn_t_pre * self.r
        dh_prev += self.Wnh.T @ (dn_t_pre * self.r)  # Accumulate dh_prev

        # Gradient wrt reset gate r
        dr = dn_t_pre * (self.Wnh @ self.hidden + self.bnh)  # (hidden_dim,)
        dr_t_pre = self.r_act.backward(dr)  # (hidden_dim,)

        # Gradients wrt Wrx, brx, and x
        self.dWrx += np.outer(dr_t_pre, self.x)
        self.dbrx += dr_t_pre
        dx_r = self.Wrx.T @ dr_t_pre  # (input_dim,)

        # Gradients wrt Wrh, brh, and h_prev
        self.dWrh += np.outer(dr_t_pre, self.hidden)
        self.dbrh += dr_t_pre
        dh_prev += self.Wrh.T @ dr_t_pre  # Accumulate dh_prev

        # Backpropagate through update gate z
        dz_t_pre = self.z_act.backward(dz)  # (hidden_dim,)

        # Gradients wrt Wzx, bzx, and x
        self.dWzx += np.outer(dz_t_pre, self.x)
        self.dbzx += dz_t_pre
        dx_z = self.Wzx.T @ dz_t_pre  # (input_dim,)

        # Gradients wrt Wzh, bzh, and h_prev
        self.dWzh += np.outer(dz_t_pre, self.hidden)
        self.dbzh += dz_t_pre
        dh_prev += self.Wzh.T @ dz_t_pre  # Accumulate dh_prev

        # Accumulate gradient with respect to x
        dx = dx_n + dx_r + dx_z  # (input_dim,)

        # Assertions
        assert dx.shape == (self.d,)
        assert dh_prev.shape == (self.h,)

        return dx, dh_prev
