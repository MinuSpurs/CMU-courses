import torch
import numpy as np
from torchsummaryX import summary
import sklearn
import gc
import zipfile
import pandas as pd
from tqdm.auto import tqdm
import os
import datetime
import wandb
import torchaudio.transforms as T
import numpy as np
from collections import Counter

device = 'cuda' if torch.cuda.is_available() else 'cpu'

### PHONEME LIST
PHONEMES = [
            '[SIL]',   'AA',    'AE',    'AH',    'AO',    'AW',    'AY',
            'B',     'CH',    'D',     'DH',    'EH',    'ER',    'EY',
            'F',     'G',     'HH',    'IH',    'IY',    'JH',    'K',
            'L',     'M',     'N',     'NG',    'OW',    'OY',    'P',
            'R',     'S',     'SH',    'T',     'TH',    'UH',    'UW',
            'V',     'W',     'Y',     'Z',     'ZH',    '[SOS]', '[EOS]']

with open("/home/work/.kaggle/kaggle.json", "w+") as f:
    f.write('{"username":"gapbu123","key":"9aead84bcd4b2de7b74761101e6ffe3f"}')

class AudioDataset(torch.utils.data.Dataset):

    def __init__(self, root, phonemes = PHONEMES, context=0, partition= "train-clean-100"): 

        self.context = context
        self.phonemes = phonemes

        self.mfcc_dir       = os.path.join(root, partition, "mfcc")
        self.transcript_dir = os.path.join(root, partition, "transcript")

        mfcc_names          = sorted(os.listdir(self.mfcc_dir))
        transcript_names    = sorted(os.listdir(self.transcript_dir))

        assert len(mfcc_names) == len(transcript_names)

        self.mfccs, self.transcripts = [], []

        for i in range(len(mfcc_names)):
            mfcc        = np.load(os.path.join(self.mfcc_dir, mfcc_names[i]))
            mfcc = (mfcc - np.mean(mfcc, axis=0)) / np.std(mfcc, axis=0)
            transcript  = np.load(os.path.join(self.transcript_dir, transcript_names[i]))
            
            if transcript[0] == '[SOS]':
                transcript = transcript[1:]
            if transcript[-1] == '[EOS]':
                transcript = transcript[:-1]

            self.mfccs.append(mfcc)
            self.transcripts.append(transcript)

        self.mfccs          = np.concatenate(self.mfccs, axis=0)
        self.transcripts    = np.concatenate([np.array(transcript) for transcript in self.transcripts])
        self.length = len(self.mfccs)
        padding = np.zeros((context, self.mfccs.shape[1]))
        self.mfccs = np.vstack((padding, self.mfccs, padding)) # TODO
        self.transcripts = np.array([self.phonemes.index(p) for p in self.transcripts])

    def __len__(self):
        return self.length

    def __getitem__(self, ind):
        frames = self.mfccs[ind:ind + 2 * self.context + 1]
        frames = frames.flatten() 
        frames      = torch.FloatTensor(frames)
        phonemes    = torch.tensor(self.transcripts[ind])

        return frames, phonemes

class AudioTestDataset(torch.utils.data.Dataset):

    def __init__(self, root, context=0, partition="test-clean"): 
        self.context = context
        self.mfcc_dir = os.path.join(root, partition, "mfcc") 
        mfcc_names = sorted(os.listdir(self.mfcc_dir))
        self.mfccs = []
        for i in range(len(mfcc_names)):
            mfcc = np.load(os.path.join(self.mfcc_dir, mfcc_names[i]))
            mfcc = (mfcc - np.mean(mfcc, axis=0)) / np.std(mfcc, axis=0)
            self.mfccs.append(mfcc)
        self.mfccs = np.concatenate(self.mfccs, axis=0)
        self.length = len(self.mfccs)
        padding = np.zeros((context, self.mfccs.shape[1]))
        self.mfccs = np.vstack((padding, self.mfccs, padding))

    def __len__(self):
        return self.length

    def __getitem__(self, ind):
        frames = self.mfccs[ind:ind + 2 * self.context + 1]
        frames = frames.flatten()
        frames = torch.FloatTensor(frames)
        return frames


config = {
    'epochs'        : 90,
    'batch_size'    : 4096,
    'context'       : 25,
    'init_lr'       : 1e-3,
    'architecture'  : 'very-low-cutoff'
}

root = '/home/work/jupyter/minwoo/CMU/11785-f24-hw1p2'

train_data = AudioDataset(root=root, phonemes=PHONEMES, context=25, partition="train-clean-100")
val_data = AudioDataset(root=root, phonemes=PHONEMES, context=25, partition="dev-clean")
test_data = AudioTestDataset(root=root, context=25, partition="test-clean")



transcript_dir = '/home/work/jupyter/minwoo/CMU/11785-f24-hw1p2/dev-clean/transcript'

phoneme_counts = Counter()

for transcript_file in os.listdir(transcript_dir):
    if transcript_file.endswith('.npy'):
        transcript_path = os.path.join(transcript_dir, transcript_file)
        transcript = np.load(transcript_path, allow_pickle=True)
        phoneme_counts.update(transcript)


least_common_phoneme = phoneme_counts.most_common()[-1] 
print(f"Least common phoneme: {least_common_phoneme[0]} with count {least_common_phoneme[1]}")

transcript_dir = '/home/work/jupyter/minwoo/CMU/11785-f24-hw1p2/dev-clean/transcript'

sil_count = 0

for transcript_file in os.listdir(transcript_dir):
    if transcript_file.endswith('.npy'):
        transcript_path = os.path.join(transcript_dir, transcript_file)
        transcript = np.load(transcript_path, allow_pickle=True)
        sil_count += np.sum(transcript == '[SIL]')

print(f'Total number of "SIL" in the dev set: {sil_count}')

train_loader = torch.utils.data.DataLoader(
    dataset     = train_data,
    num_workers = 4,
    batch_size  = config['batch_size'],
    pin_memory  = True,
    shuffle     = True
)

val_loader = torch.utils.data.DataLoader(
    dataset     = val_data,
    num_workers = 2,
    batch_size  = config['batch_size'],
    pin_memory  = True,
    shuffle     = False
)

test_loader = torch.utils.data.DataLoader(
    dataset     = test_data,
    num_workers = 2,
    batch_size  = config['batch_size'],
    pin_memory  = True,
    shuffle     = False
)


print("Batch size     : ", config['batch_size'])
print("Context        : ", config['context'])
print("Input size     : ", (2*config['context']+1)*28)
print("Output symbols : ", len(PHONEMES))

print("Train dataset samples = {}, batches = {}".format(train_data.__len__(), len(train_loader)))
print("Validation dataset samples = {}, batches = {}".format(val_data.__len__(), len(val_loader)))
print("Test dataset samples = {}, batches = {}".format(test_data.__len__(), len(test_loader)))


for i, data in enumerate(train_loader):
    frames, phoneme = data
    print(frames.shape, phoneme.shape)
    break

class Network(torch.nn.Module):
    def __init__(self, input_size, output_size):
        super(Network, self).__init__()
        
        self.model = torch.nn.Sequential(
            torch.nn.Linear(input_size, 2048),
            torch.nn.BatchNorm1d(2048),
            torch.nn.GELU(),
            torch.nn.Dropout(p=0.15),  
            torch.nn.Linear(2048, 2048),
            torch.nn.BatchNorm1d(2048),
            torch.nn.GELU(),
            torch.nn.Dropout(p=0.15),  
            torch.nn.Linear(2048, 2048),
            torch.nn.BatchNorm1d(2048),
            torch.nn.GELU(),
            torch.nn.Dropout(p=0.15), 
            torch.nn.Linear(2048, 2048),
            torch.nn.BatchNorm1d(2048),
            torch.nn.GELU(),
            torch.nn.Dropout(p=0.15), 
            torch.nn.Linear(2048, 1024),
            torch.nn.BatchNorm1d(1024),
            torch.nn.GELU(),
            torch.nn.Dropout(p=0.15),  
            torch.nn.Linear(1024, 1024),
            torch.nn.BatchNorm1d(1024),
            torch.nn.GELU(),
            torch.nn.Linear(1024, 512),
            torch.nn.BatchNorm1d(512),
            torch.nn.GELU(),
            torch.nn.Linear(512, 256),
            torch.nn.BatchNorm1d(256),
            torch.nn.GELU(),
            torch.nn.Linear(256, 128),
            torch.nn.BatchNorm1d(128),
            torch.nn.GELU(),
            torch.nn.Linear(128, output_size)
        )
        self.model.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, torch.nn.Linear):
            torch.nn.init.kaiming_normal_(m.weight)

    def forward(self, x):
        out = self.model(x)
        return out

INPUT_SIZE  = (2*config['context'] + 1) * 28 
model       = Network(INPUT_SIZE, len(train_data.phonemes)).to(device)
print(INPUT_SIZE)
print(frames.shape)
summary(model, frames.to(device))


criterion = torch.nn.CrossEntropyLoss() 

optimizer = torch.optim.AdamW(model.parameters(), lr=config['init_lr'], weight_decay=0.01)

scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[60, 80], gamma=0.1)

time_masking = T.TimeMasking(time_mask_param=15) 
freq_masking = T.FrequencyMasking(freq_mask_param=15)

def apply_masking(mfccs):
    mfccs = time_masking(mfccs)
    mfccs = freq_masking(mfccs)
    return mfccs


torch.cuda.empty_cache()
gc.collect()

def train(model, dataloader, optimizer, criterion, scheduler):

    model.train()
    tloss, tacc = 0, 0
    batch_bar   = tqdm(total=len(dataloader), dynamic_ncols=True, leave=False, position=0, desc='Train')

    for i, (frames, phonemes) in enumerate(dataloader):
        optimizer.zero_grad()
        frames = frames.to(device)
        phonemes = phonemes.to(device)
        frames = apply_masking(frames)
        logits  = model(frames)
        loss    = criterion(logits, phonemes)
        loss.backward()
        optimizer.step()

        tloss   += loss.item()
        tacc    += torch.sum(torch.argmax(logits, dim=1) == phonemes).item() / logits.shape[0]

        batch_bar.set_postfix(loss="{:.04f}".format(float(tloss / (i + 1))),
                              acc="{:.04f}%".format(float(tacc*100 / (i + 1))))
        batch_bar.update()

        del frames, phonemes, logits
        torch.cuda.empty_cache()


    scheduler.step()

    batch_bar.close()
    return tloss / len(dataloader), tacc / len(dataloader)

def eval(model, dataloader):

    model.eval() 
    vloss, vacc = 0, 0 
    batch_bar   = tqdm(total=len(val_loader), dynamic_ncols=True, position=0, leave=False, desc='Val')

    for i, (frames, phonemes) in enumerate(dataloader):
        frames      = frames.to(device)
        phonemes    = phonemes.to(device)
        with torch.inference_mode():
            logits  = model(frames)
            loss    = criterion(logits, phonemes)

        vloss   += loss.item()
        vacc    += torch.sum(torch.argmax(logits, dim= 1) == phonemes).item()/logits.shape[0]

        batch_bar.set_postfix(loss="{:.04f}".format(float(vloss / (i + 1))),
                              acc="{:.04f}%".format(float(vacc*100 / (i + 1))))
        batch_bar.update()

        del frames, phonemes, logits
        torch.cuda.empty_cache()

    batch_bar.close()
    vloss   /= len(val_loader)
    vacc    /= len(val_loader)

    return vloss, vacc

wandb.login(key="f20506dbcca14d82ab5324952dad2c08e99085e2")

run = wandb.init(
    name    = "first-run", 
    reinit  = True,
    project = "hw1p2", 
    config  = config 
)

model_arch  = str(model)

arch_file   = open("model_arch.txt", "w")
file_write  = arch_file.write(model_arch)
arch_file.close()

wandb.save('model_arch.txt')

best_val_acc = 0.0

for epoch in range(config['epochs']):

    print("\nEpoch {}/{}".format(epoch+1, config['epochs']))

    curr_lr = float(optimizer.param_groups[0]['lr'])
    train_loss, train_acc = train(model, train_loader, optimizer, criterion, scheduler)
    val_loss, val_acc = eval(model, val_loader)

    print("\tTrain Acc {:.04f}%\tTrain Loss {:.04f}\t Learning Rate {:.07f}".format(train_acc*100, train_loss, curr_lr))
    print("\tVal Acc {:.04f}%\tVal Loss {:.04f}".format(val_acc*100, val_loss))

    wandb.log({'train_acc': train_acc*100, 'train_loss': train_loss,
               'val_acc': val_acc*100, 'valid_loss': val_loss, 'lr': curr_lr})
    
    if val_acc > best_val_acc:
        print("\tValidation accuracy improved from {:.04f}% to {:.04f}%! Saving checkpoint...".format(best_val_acc*100, val_acc*100))

        checkpoint_path = f"/home/work/jupyter/minwoo/CMU/checkpoint_epoch_{epoch+1}.pth"
        
        torch.save({
            'epoch': epoch + 1,             
            'model_state_dict': model.state_dict(),  
            'optimizer_state_dict': optimizer.state_dict(),  
            'loss': val_loss,                
            'val_acc': val_acc               
        }, checkpoint_path)

        wandb.save(checkpoint_path)

        best_val_acc = val_acc

def test(model, test_loader):
    model.eval() 
    test_predictions = []

    with torch.no_grad():  
        for i, mfccs in enumerate(tqdm(test_loader)):
            mfccs = mfccs.to(device)
            logits = model(mfccs)
            predicted_phonemes = torch.argmax(logits, dim=1)
            test_predictions.extend(predicted_phonemes.cpu().numpy())

    return test_predictions

def map_id_to_phoneme(predicted_ids):
    return [PHONEMES[id] for id in predicted_ids]

best_val_acc = 0.0

for epoch in range(config['epochs']):
    print(f"\nEpoch {epoch+1}/{config['epochs']}")

    curr_lr = float(optimizer.param_groups[0]['lr'])
    train_loss, train_acc = train(model, train_loader, optimizer, criterion, scheduler)
    val_loss, val_acc = eval(model, val_loader)

    print(f"\tTrain Acc {train_acc*100:.04f}%\tTrain Loss {train_loss:.04f}\t Learning Rate {curr_lr:.07f}")
    print(f"\tVal Acc {val_acc*100:.04f}%\tVal Loss {val_loss:.04f}")

    wandb.log({
        'train_acc': train_acc * 100,
        'train_loss': train_loss,
        'val_acc': val_acc * 100,
        'valid_loss': val_loss,
        'lr': curr_lr
    })

    predictions = test(model, test_loader)
    phoneme_predictions = map_id_to_phoneme(predictions)

    if val_acc > best_val_acc:
        print(f"\tValidation accuracy improved from {best_val_acc*100:.04f}% to {val_acc*100:.04f}%! Saving checkpoint...")

        checkpoint_path = f"/home/work/jupyter/minwoo/CMU/checkpoint_epoch_{epoch+1}.pth"
        torch.save({
            'epoch': epoch + 1,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'loss': val_loss,
            'val_acc': val_acc
        }, checkpoint_path)
        wandb.save(checkpoint_path, base_path="/home/work/jupyter/minwoo/CMU/")

        best_val_acc = val_acc

        submission_path = f"/home/work/jupyter/minwoo/CMU/submission_epoch_{epoch+1}.csv"
        with open(submission_path, "w+") as f:
            f.write("id,label\n")
            for i, prediction in enumerate(phoneme_predictions):
                f.write(f"{i},{prediction}\n")

        print(f"Submission file saved at {submission_path}")

run.finish()